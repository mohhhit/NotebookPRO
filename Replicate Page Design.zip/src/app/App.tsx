import { useState, useRef, useEffect } from "react";

function GeminiLogo() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M12 2C12 2 14.5 8 20 10C14.5 12 12 18 12 18C12 18 9.5 12 4 10C9.5 8 12 2 12 2Z"
        fill="url(#gemini-gradient)"
      />
      <defs>
        <linearGradient id="gemini-gradient" x1="4" y1="2" x2="20" y2="18" gradientUnits="userSpaceOnUse">
          <stop stopColor="#4285F4" />
          <stop offset="0.5" stopColor="#9B59B6" />
          <stop offset="1" stopColor="#EA4335" />
        </linearGradient>
      </defs>
    </svg>
  );
}

function MicIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z" fill="#9aa0a6" />
      <path d="M19 10v2a7 7 0 0 1-14 0v-2H3v2a9 9 0 0 0 8 8.94V23h2v-2.06A9 9 0 0 0 21 12v-2h-2z" fill="#9aa0a6" />
    </svg>
  );
}

function ToolsIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function PlusIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 5v14M5 12h14" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

function HamburgerIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M3 6h18M3 12h18M3 18h18" stroke="#e8eaed" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

function SearchIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="11" cy="11" r="8" stroke="#9aa0a6" strokeWidth="2" />
      <path d="m21 21-4.35-4.35" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

function NewChatIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function MyStuffIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M20 7H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function GemsIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function SettingsIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="12" cy="12" r="3" stroke="#9aa0a6" strokeWidth="2" />
      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" stroke="#9aa0a6" strokeWidth="2" />
    </svg>
  );
}

function ChevronRightIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M9 18l6-6-6-6" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function ChevronDownIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M6 9l6 6 6-6" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function ComposeIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 20h9" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function UploadIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      <polyline points="17 8 12 3 7 8" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      <line x1="12" y1="3" x2="12" y2="15" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

function DriveIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 2L2 19.5h20L12 2z" stroke="#9aa0a6" strokeWidth="2" strokeLinejoin="round" />
      <path d="M2 19.5l5-8.5h10l5 8.5" stroke="#9aa0a6" strokeWidth="2" strokeLinejoin="round" />
    </svg>
  );
}

function PhotosIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="3" y="3" width="18" height="18" rx="2" ry="2" stroke="#9aa0a6" strokeWidth="2" />
      <circle cx="8.5" cy="8.5" r="1.5" stroke="#9aa0a6" strokeWidth="2" />
      <polyline points="21 15 16 10 5 21" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function CodeIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <polyline points="16 18 22 12 16 6" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      <polyline points="8 6 2 12 8 18" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function NotebookIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function ChatBubbleIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function SummarizeIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <line x1="21" y1="6" x2="3" y2="6" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" />
      <line x1="15" y1="12" x2="3" y2="12" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" />
      <line x1="17" y1="18" x2="3" y2="18" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

function ExplainIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="12" cy="12" r="10" stroke="#9aa0a6" strokeWidth="2" />
      <line x1="12" y1="8" x2="12" y2="12" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" />
      <line x1="12" y1="16" x2="12.01" y2="16" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

function StudyNotesIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      <polyline points="14 2 14 8 20 8" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      <line x1="16" y1="13" x2="8" y2="13" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" />
      <line x1="16" y1="17" x2="8" y2="17" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" />
      <polyline points="10 9 9 9 8 9" stroke="#9aa0a6" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

const plusMenuItems = [
  { id: 1, label: "Upload files", icon: <UploadIcon /> },
  { id: 2, label: "Add from Drive", icon: <DriveIcon /> },
  { id: 3, label: "Photos", icon: <PhotosIcon /> },
  { id: 4, label: "Import code", icon: <CodeIcon /> },
  { id: 5, label: "NotebookLM", icon: <NotebookIcon /> },
];

const toolsMenuItems = [
  { id: 1, label: "Chat", icon: <ChatBubbleIcon /> },
  { id: 2, label: "Summarize", icon: <SummarizeIcon /> },
  { id: 3, label: "Explain", icon: <ExplainIcon /> },
  { id: 4, label: "Study Notes", icon: <StudyNotesIcon /> },
];

const chatHistory = [
  "Time Series Trends Not Found",
  "Building a RAG System Locally",
  "NLP to SQL/MongoDB Presentation Sl...",
  "vector art of a beautiful feather of pe...",
  "NLP Project Topic Suggestions",
  "SQL Translation Error and Correction",
  "Hey, i am trying to learn about Credit ...",
  "Bright LED Flashlight Configuration",
  "Fixing Unreadable Folder Errors",
  "Resume Building for Desktop Support",
  "Desktop Upgrade for LLM Training",
  "Bread Pakora Recipe Ideas",
  "Multilingual Greetings Dataset Creati...",
  "Data Visualization Exam Study Guide",
  "Data Governance Exam Topic Prioriti...",
];


export default function App() {
  const [inputValue, setInputValue] = useState("");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [plusMenuOpen, setPlusMenuOpen] = useState(false);
  const [toolsMenuOpen, setToolsMenuOpen] = useState(false);
  const [activeToolLabel, setActiveToolLabel] = useState<string | null>(null);
  const plusMenuRef = useRef<HTMLDivElement>(null);
  const toolsMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (plusMenuRef.current && !plusMenuRef.current.contains(e.target as Node)) {
        setPlusMenuOpen(false);
      }
      if (toolsMenuRef.current && !toolsMenuRef.current.contains(e.target as Node)) {
        setToolsMenuOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div
      className="flex flex-col size-full min-h-screen overflow-hidden relative"
      style={{ backgroundColor: "#0d0d0d", color: "#e8eaed" }}
    >
      {/* Overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-20"
          style={{ backgroundColor: "rgba(0,0,0,0.4)" }}
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar Drawer */}
      <aside
        className="fixed top-0 left-0 h-full z-30 flex flex-col"
        style={{
          width: "260px",
          backgroundColor: "#171717",
          transform: sidebarOpen ? "translateX(0)" : "translateX(-100%)",
          transition: "transform 0.25s cubic-bezier(0.4,0,0.2,1)",
          boxShadow: sidebarOpen ? "4px 0 24px rgba(0,0,0,0.5)" : "none",
        }}
      >
        {/* Sidebar Top */}
        <div className="flex items-center justify-between px-3 py-3" style={{ minHeight: "56px" }}>
          <button
            className="p-2 rounded-full hover:bg-white/10 transition-colors"
            onClick={() => setSidebarOpen(false)}
          >
            <HamburgerIcon />
          </button>
          <button className="p-2 rounded-full hover:bg-white/10 transition-colors">
            <SearchIcon />
          </button>
        </div>

        {/* Sidebar Nav Items */}
        <div className="px-2 pb-2">
          <button
            className="w-full flex items-center justify-between px-3 py-2.5 rounded-full hover:bg-white/10 transition-colors group"
          >
            <div className="flex items-center gap-3">
              <NewChatIcon />
              <span style={{ color: "#e8eaed", fontSize: "14px" }}>New chat</span>
            </div>
            <div className="opacity-0 group-hover:opacity-100 transition-opacity">
              <ComposeIcon />
            </div>
          </button>

          <button
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-full hover:bg-white/10 transition-colors"
          >
            <MyStuffIcon />
            <span style={{ color: "#e8eaed", fontSize: "14px" }}>My stuff</span>
          </button>
        </div>

        {/* Gems Section */}
        <div className="px-2 pb-1">
          <button
            className="w-full flex items-center justify-between px-3 py-2 rounded-lg hover:bg-white/10 transition-colors"
          >
            <div className="flex items-center gap-3">
              <GemsIcon />
              <span style={{ color: "#e8eaed", fontSize: "14px", fontWeight: "500" }}>Gems</span>
            </div>
            <ChevronRightIcon />
          </button>
        </div>

        {/* Divider */}
        <div style={{ height: "1px", backgroundColor: "#2a2a2a", margin: "4px 12px" }} />

        {/* Chats Section */}
        <div className="px-2 pt-2 flex-1 overflow-y-auto" style={{ scrollbarWidth: "none" }}>
          <p
            className="px-3 pb-1"
            style={{ color: "#9aa0a6", fontSize: "12px", fontWeight: "500", letterSpacing: "0.3px" }}
          >
            Chats
          </p>
          {chatHistory.map((chat, index) => (
            <button
              key={index}
              className="w-full text-left px-3 py-2 rounded-lg hover:bg-white/10 transition-colors"
              style={{ color: "#c8cacc", fontSize: "13px", display: "block", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}
            >
              {chat}
            </button>
          ))}
        </div>

        {/* Settings at bottom */}
        <div style={{ borderTop: "1px solid #2a2a2a" }} className="px-2 py-3">
          <button
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-full hover:bg-white/10 transition-colors"
          >
            <SettingsIcon />
            <span style={{ color: "#e8eaed", fontSize: "14px" }}>Settings and help</span>
          </button>
        </div>
      </aside>

      {/* Top Navigation */}
      <header
        className="flex items-center justify-between px-4 py-3 relative z-10"
        style={{ borderBottom: "1px solid #1e1e1e" }}
      >
        <div className="flex items-center gap-3">
          <button
            className="p-2 rounded-full hover:bg-white/10 transition-colors"
            onClick={() => setSidebarOpen((v) => !v)}
          >
            <HamburgerIcon />
          </button>
          <span style={{ color: "#e8eaed", fontSize: "18px", fontWeight: "400", letterSpacing: "0.2px" }}>
            Gemini
          </span>
        </div>
        <div className="flex items-center gap-3">
          <span
            className="px-2 py-0.5 rounded text-xs"
            style={{ color: "#9aa0a6", border: "1px solid #444", letterSpacing: "1px" }}
          >
            PRO
          </span>
          <button
            className="w-8 h-8 rounded-full flex items-center justify-center"
            style={{ background: "linear-gradient(135deg, #4285F4, #EA4335, #FBBC04, #34A853)" }}
          >
            <span style={{ color: "white", fontSize: "13px", fontWeight: "600" }}>M</span>
          </button>
        </div>
      </header>

      {/* Body */}
      <div className="flex flex-1">
        {/* Main Content */}
        <main className="flex-1 flex flex-col items-center justify-center" style={{ paddingBottom: "80px" }}>
          {/* Greeting */}
          <div className="mb-6" style={{ maxWidth: "420px", width: "100%" }}>
            <div className="flex items-center gap-2 mb-1" style={{ paddingLeft: "2px" }}>
              <GeminiLogo />
              <span style={{ color: "#e8eaed", fontSize: "22px", fontWeight: "400" }}>
                Hi Mohit
              </span>
            </div>
            <h1 style={{ color: "#e8eaed", fontSize: "28px", fontWeight: "400", lineHeight: "1.3" }}>
              Where should we start?
            </h1>
          </div>

          {/* Input Box */}
          <div
            className="rounded-2xl p-3 relative"
            style={{
              backgroundColor: "#1e1e1e",
              width: "100%",
              maxWidth: "420px",
            }}
          >
            <textarea
              className="w-full bg-transparent outline-none resize-none"
              style={{
                color: "#e8eaed",
                fontSize: "14px",
                minHeight: "32px",
                maxHeight: "200px",
                caretColor: "#e8eaed",
              }}
              placeholder="Ask Gemini 3"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              rows={1}
              onInput={(e) => {
                const target = e.target as HTMLTextAreaElement;
                target.style.height = "auto";
                target.style.height = target.scrollHeight + "px";
              }}
            />
            {/* Toolbar */}
            <div className="flex items-center justify-between mt-2">
              <div className="flex items-center gap-1 relative" ref={plusMenuRef}>
                <button
                  className="flex items-center justify-center w-8 h-8 rounded-full hover:bg-white/10 transition-colors"
                  onClick={() => setPlusMenuOpen((v) => !v)}
                >
                  <PlusIcon />
                </button>

                {/* Plus Menu Popup */}
                {plusMenuOpen && (
                  <div
                    className="absolute bottom-10 left-0 rounded-2xl py-1 z-50"
                    style={{
                      backgroundColor: "#2a2a2a",
                      minWidth: "190px",
                      boxShadow: "0 8px 32px rgba(0,0,0,0.5)",
                    }}
                  >
                    {plusMenuItems.map((item) => (
                      <button
                        key={item.id}
                        className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-white/10 transition-colors text-left"
                        style={{ color: "#e8eaed", fontSize: "14px" }}
                        onClick={() => setPlusMenuOpen(false)}
                      >
                        {item.icon}
                        <span>{item.label}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <div className="flex items-center gap-2" ref={toolsMenuRef} style={{ position: "relative" }}>
                <button
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-full transition-colors"
                  style={{
                    color: toolsMenuOpen || activeToolLabel ? "#e8eaed" : "#9aa0a6",
                    fontSize: "13px",
                    backgroundColor: toolsMenuOpen || activeToolLabel ? "#3c3c3c" : "transparent",
                  }}
                  onClick={() => setToolsMenuOpen((v) => !v)}
                >
                  <ToolsIcon />
                  <span>{activeToolLabel ?? "Tools"}</span>
                </button>

                {/* Tools Menu Popup */}
                {toolsMenuOpen && (
                  <div
                    className="absolute rounded-2xl z-50 py-2"
                    style={{
                      bottom: "calc(100% + 8px)",
                      right: 0,
                      backgroundColor: "#2a2a2a",
                      minWidth: "200px",
                      boxShadow: "0 8px 32px rgba(0,0,0,0.6)",
                    }}
                  >
                    <p
                      className="px-4 pb-2 pt-1"
                      style={{ color: "#9aa0a6", fontSize: "12px", fontWeight: "600", letterSpacing: "0.5px", textTransform: "uppercase" }}
                    >
                      Tools
                    </p>
                    {toolsMenuItems.map((item) => (
                      <button
                        key={item.id}
                        className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-white/10 transition-colors text-left"
                        style={{
                          color: activeToolLabel === item.label ? "#8ab4f8" : "#e8eaed",
                          fontSize: "14px",
                          backgroundColor: activeToolLabel === item.label ? "rgba(138,180,248,0.1)" : "transparent",
                        }}
                        onClick={() => {
                          setActiveToolLabel(activeToolLabel === item.label ? null : item.label);
                          setToolsMenuOpen(false);
                        }}
                      >
                        {item.icon}
                        <span>{item.label}</span>
                        {activeToolLabel === item.label && (
                          <span className="ml-auto" style={{ color: "#8ab4f8", fontSize: "16px" }}>✓</span>
                        )}
                      </button>
                    ))}
                  </div>
                )}

                <button className="flex items-center justify-center w-8 h-8 rounded-full hover:bg-white/10 transition-colors">
                  <MicIcon />
                </button>
              </div>
            </div>
          </div>


        </main>
      </div>
    </div>
  );
}