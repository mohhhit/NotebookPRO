
  # Replicate Page Design

  This is a code bundle for Replicate Page Design. The original project is available at https://www.figma.com/design/ZIiUnq7jv6J8sJqAXwQmzD/Replicate-Page-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  